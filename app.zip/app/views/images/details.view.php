<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 4:15 PM
 */

include ('./app/views/layouts/header.view.php');
?>

<div id="container">
    <div class="content">
        <div id="movie">
        <img style="width: 100%" src="/uploads/<?php echo $image['path'] ?>" alt="">
        </div>
    </div>
    <div style="clear:both"></div>
        <br>
    <div class="row">
        <div class="col-sm-0">
            <div class="thumbnail">
                <img class="img-responsive user-photo" src="">
            </div><!-- /thumbnail -->
        </div><!-- /col-sm-1 -->

        <div class="col-sm-7">
            <div id="comments"></div>
        </div><!-- /col-sm-5 -->
    </div>

    <div class="col-md-6">
        <div class="widget-area no-padding blank">
            <div class="status-upload">
               <div id="comment_form"> <!-- method="post" action="/comment"-->
                    <textarea placeholder="What are you doing right now?" name="comment"></textarea>
                    <ul>
                        <li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Audio"><i class="fa fa-music"></i></a></li>
                        <li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Video"><i class="fa fa-video-camera"></i></a></li>
                        <li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Sound Record"><i class="fa fa-microphone"></i></a></li>
                        <li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Picture"><i class="fa fa-picture-o"></i></a></li>
                    </ul>
                    <input type="hidden" name="_token" value="<?php echo \security\Csrf::getToken()?>">
                    <input type="hidden" name="id" value="<?php echo $image['id']?>">
                   <div class="g-recaptcha" data-sitekey="YOUR_KEY"></div>
                <button type="submit" id="submit-comment" class="btn btn-success green"><i class="fa fa-share"></i> Share</button>
               </div>
            </div><!-- Status Upload  -->
        </div><!-- Widget Area -->
    </div>
    <div style="clear:both; height: 40px"></div>
</div>
<!-- close container -->
<?php
include ('./app/views/layouts/footer.view.php');
?>

