<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 18.10.2018 г.
 * Time: 10:47
 */

include ("./app/views/admin/layouts/header.view.php");
?>


<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 18.10.2018 г.
 * Time: 10:47
 */

include ("./app/views/admin/layouts/footer.view.php");
?>
