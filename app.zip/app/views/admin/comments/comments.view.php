<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/31/2018
 * Time: 3:47 PM
 */

include ROOT_PATH."/app/views/admin/layouts/header.view.php";
?>

<div class="container">
    <div class="row ">
        <div class="list-group">
            <div class="panel-heading">
                <span class="glyphicon glyphicon-comment"></span>
                <h3 class="panel-title">
                    Recent Comments</h3>
                <span class="label label-info">
                    78</span>
            </div>
            <div class="panel-body ">
                <ul class="list-group">
                    <?php foreach ($comments as $comment){ ?>
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-xs-2 col-md-1">
                                <img src="http://placehold.it/80" class="img-circle img-responsive" alt="" /></div>
                            <div class="col-xs-10 col-md-11">
<!--                                <div>-->
<!--                                    <a href="http://www.jquery2dotnet.com/2013/10/google-style-login-page-desing-usign.html">-->
<!--                                        Google Style Login Page Design Using Bootstrap</a>-->
<!--                                    <div class="mic-info">-->
<!--                                        By: <a href="#">Bhaumik Patel</a> on 2 Aug 2013-->
<!--                                    </div>-->
<!--                                </div>-->
                                <div class="comment-text">
                                    <?php echo $comment["content"]?>
                                </div>
                                <div class="action">
                                    <button type="button" class="btn btn-primary btn-xs" title="Edit">
                                        <span class="glyphicon glyphicon-pencil"></span>
                                    </button>
                                    <button type="button" class="btn btn-success btn-xs" title="Approved">
                                        <span class="glyphicon glyphicon-ok"></span>
                                    </button>
                                    <button type="button" class="btn btn-danger btn-xs" title="Delete">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php }?>
                </ul>
                <a href="#" class="btn btn-primary btn-sm btn-block" role="button"><span class="glyphicon glyphicon-refresh"></span> More</a>
            </div>
        </div>
    </div>
</div>

<?php
include ROOT_PATH."/app/views/admin/layouts/footer.view.php";
?>