<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/31/2018
 * Time: 9:54 AM
 */
?>

<?php foreach ($comments as $comment){?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <strong> <?php
                if($comment['user_id'] != null)
                    echo $comment['user_id'];
                else
                    echo "Anonymous";
                ?>
            </strong>
            <span class="text-muted"><?php $date = $comment["created_at"];$format = date("m-d-Y", strtotime($date));echo $format;?></span>
            <input  type="hidden" name="comment_id" value="<?php echo $comment["id"]?>">

            <div class="btn-group">
                <button type="button" id="remove-comment" class="btn btn-outline-danger">remove</button>
                <button type="button" id="edit-comment"class="btn btn-outline-primary">edit</button>
            </div>
        </div>
        <div class="panel-body">
            <?php echo $comment['content'] ?>
        </div><!-- /panel-body -->
    </div><!-- /panel panel-default -->
<?php } ?>
