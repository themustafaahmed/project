<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 19:17
 */
namespace app\controllers\Admin;
use app\controllers\Controller;
use app\models\Comment;
use app\models\Image;
use app\models\Setting;
use helpers\Request;

class AdminController extends Controller
{
    public function home(){

        return $this->view('admin/home');
    }

    public function images(){
        $images = (new Image())->get();
        return $this->view('admin/images/images',compact('images'));
    }

    public function remove_image($id){
        $image = (new Image())->where("id",$id)->delete();
        if($image){
            return $this->redirect('/admin/images');
        }
       return "err";
    }

    public function users(){

        return $this->view('admin/users/users');
    }

    public function comments(){
        $comments = (new Comment())->get();
        return $this->view('admin/comments/comments',compact('comments'));
    }

    public function settings(){
        $settings = (new Setting())->get();
        return $this->view('admin/settings/settings',compact('settings'));
    }

    public function settingsSave($allow){
        $settings = (new Setting())->where("id",1)->update(['allow_anon_comment'=>$allow]);
        if($settings){
            echo "ok";
        }else{
            echo "err";
        }
    }
}