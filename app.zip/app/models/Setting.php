<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/31/2018
 * Time: 4:46 PM
 */

namespace app\models;


use database\Database;

class Setting extends Database
{
    protected static $table = "settings";
}