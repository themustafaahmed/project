<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 16.10.2018 г.
 * Time: 15:38
 */

$controllers = MAIN_PATH."app/controllers";
$models = MAIN_PATH."app/models";
$router = MAIN_PATH."routes";
$security = MAIN_PATH."security";
$helpers = MAIN_PATH."helpers";
$database = MAIN_PATH."database";
$config = MAIN_PATH."config";

$q = set_include_path($controllers.
    PATH_SEPARATOR.$models.
    PATH_SEPARATOR.$router.
    PATH_SEPARATOR.$helpers.
    PATH_SEPARATOR.$database.
    PATH_SEPARATOR.$config.
    PATH_SEPARATOR.$security
);
spl_autoload_register();
