﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace SplitAndMerge
{
    // Връща променлива на средата
    class GetEnvFunction : ParserFunction
    {
        protected override Variable Evaluate(string data, ref int from)
        {
            string varName = Utils.GetToken(data, ref from, Constants.END_ARG_ARRAY);
            string res = Environment.GetEnvironmentVariable(varName);

            return new Variable(res);
        }
    }

    // Задава променлива на средата
    class SetEnvFunction : ParserFunction
    {
        protected override Variable Evaluate(string data, ref int from)
        {
            string varName = Utils.GetToken(data, ref from, Constants.NEXT_ARG_ARRAY);
            if (from >= data.Length)
            {
                throw new ArgumentException("Couldn't set env variable");
            }

            Variable varValue = Utils.GetItem(data, ref from);
            string strValue = varValue.AsString();
            Environment.SetEnvironmentVariable(varName, strValue);

            return new Variable(varName);
        }
    }

    // Отпечатва списък с аргументи
    class PrintFunction : ParserFunction
    {
        internal PrintFunction(Interpreter interpreter, bool newLine = true)
        {
            m_interpreter = interpreter;
            m_newLine = newLine;
        }

        protected override Variable Evaluate(string data, ref int from)
        {
            bool isList;
            List<Variable> args = Utils.GetArgs(data, ref from,
                Constants.START_ARG, Constants.END_ARG, out isList);

            string output = string.Empty;
            for (int i = 0; i < args.Count; i++)
            {
                output += args[i].AsString();
            }

            m_interpreter.AppendOutput(output, m_newLine);

            return Variable.EmptyInstance;
        }

        private Interpreter m_interpreter;
        private bool m_newLine;
    }

    // Чете низ или номер от конзолата
    class ReadConsole : ParserFunction
    {
        internal ReadConsole(bool isNumber = false)
        {
            m_isNumber = isNumber;
        }

        protected override Variable Evaluate(string data, ref int from)
        {
            from++; // Пропуснете отварящата скоба.
            string line = Console.ReadLine();

            double number = Double.NaN;
            if (m_isNumber)
            {
                if (!Double.TryParse(line, out number))
                {
                    throw new ArgumentException("Couldn't parse number [" + line + "]");
                }

                return new Variable(number);
            }

            return new Variable(line);
        }

        private bool m_isNumber;
    }


    // Напишете линия на файл
    class WriteLineFunction : ParserFunction
    {
        protected override Variable Evaluate(string data, ref int from)
        {
            string filename = Utils.GetStringOrVarValue(data, ref from);
            Variable line = Utils.GetItem(data, ref from);
            Utils.WriteFileText(filename, line.AsString() + Environment.NewLine);

            return Variable.EmptyInstance;
        }
    }

    // Напишете списък с линии във файл
    class WriteLinesFunction : ParserFunction
    {
        protected override Variable Evaluate(string data, ref int from)
        {
            //string filename = Utils.ResultToString(Utils.GetItem(data, ref from));
            string filename = Utils.GetStringOrVarValue(data, ref from);
            string lines = Utils.GetLinesFromList(data, ref from);
            Utils.WriteFileText(filename, lines);

            return Variable.EmptyInstance;
        }
    }
}