﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SplitAndMerge
{
	public class OutputAvailableEventArgs : EventArgs
	{
		public string Output { get; set; }
	}

	public class Interpreter
	{

		private static Interpreter instance;

		private Interpreter()
		{
			Init();
		}

		public static Interpreter Instance
		{
			get 
			{
				if (instance == null)
				{
					instance = new Interpreter();
				}
				return instance;
			}
		}

		private int MAX_LOOPS;

		private StringBuilder m_output = new StringBuilder();
		
		public string Output {
			get {
				string output = m_output.ToString().Trim();
				m_output.Clear();
				return output;
			}
		}

		public event EventHandler<OutputAvailableEventArgs> GetOutput;

		public void AppendOutput(string text, bool newLine = true)
		{
			EventHandler<OutputAvailableEventArgs> handler = GetOutput;
			if (handler != null)
			{
				OutputAvailableEventArgs args = new OutputAvailableEventArgs();
				args.Output = text + (newLine ? Environment.NewLine : string.Empty);
				handler(this, args);
			}
		}

		public void Init()
		{
			ParserFunction.AddGlobal(Constants.IF,          new IfStatement(this));
			ParserFunction.AddGlobal(Constants.WHILE,       new WhileStatement(this));
			ParserFunction.AddGlobal(Constants.BREAK,       new BreakStatement());
			ParserFunction.AddGlobal(Constants.CONTINUE,    new ContinueStatement());
			ParserFunction.AddGlobal(Constants.RETURN,      new ReturnStatement());
			ParserFunction.AddGlobal(Constants.FUNCTION,    new FunctionCreator(this));
			ParserFunction.AddGlobal(Constants.INCLUDE,     new IncludeFile());
			ParserFunction.AddGlobal(Constants.THROW,       new ThrowFunction());
			ParserFunction.AddGlobal(Constants.TRY,         new TryBlock(this));


			ParserFunction.AddGlobal(Constants.READ,        new ReadConsole());
			ParserFunction.AddGlobal(Constants.SET,         new SetVarFunction());
			ParserFunction.AddGlobal(Constants.SIZE,        new SizeFunction());
      		ParserFunction.AddGlobal(Constants.WRITE,       new PrintFunction(this, false));
			ParserFunction.AddGlobal(Constants.WRITELINE,   new WriteLineFunction());
			ParserFunction.AddGlobal(Constants.WRITELINES,  new WriteLinesFunction());
     		ParserFunction.AddGlobal(Constants.WRITENL,     new PrintFunction(this, true));

			ParserFunction.AddAction(Constants.ASSIGNMENT,  new AssignFunction());
			ParserFunction.AddAction(Constants.INCREMENT,   new IncrementDecrementFunction());
			ParserFunction.AddAction(Constants.DECREMENT,   new IncrementDecrementFunction());

			for (int i = 0; i < Constants.OPER_ACTIONS.Length; i++) {
				ParserFunction.AddAction(Constants.OPER_ACTIONS[i], new OperatorAssignFunction());
			}

			Constants.ELSE_LIST.Add(Constants.ELSE);
			Constants.ELSE_IF_LIST.Add(Constants.ELSE_IF);
			Constants.CATCH_LIST.Add(Constants.CATCH);

			ReadConfig();
		}

		public void ReadConfig()
		{
			MAX_LOOPS         = ReadConfig("maxLoops", 256000);

			if (ConfigurationManager.GetSection ("Languages") == null) {
				return;
			}
			var languagesSection = ConfigurationManager.GetSection("Languages") as NameValueCollection;
			if (languagesSection.Count == 0)
			{
				return;
			}

			string languages = languagesSection["languages"];
			string[] supportedLanguages = languages.Split(",".ToCharArray());

			foreach(string language in supportedLanguages)
			{
				var languageSection    = ConfigurationManager.GetSection(language) as NameValueCollection;

				AddTranslation(languageSection, Constants.IF);
				AddTranslation(languageSection, Constants.WHILE);
				AddTranslation(languageSection, Constants.BREAK);
				AddTranslation(languageSection, Constants.CONTINUE);
				AddTranslation(languageSection, Constants.RETURN);
				AddTranslation(languageSection, Constants.FUNCTION);
				AddTranslation(languageSection, Constants.INCLUDE);
				AddTranslation(languageSection, Constants.THROW);
				AddTranslation(languageSection, Constants.TRY);

	       		AddTranslation(languageSection, Constants.READ);
				AddTranslation(languageSection, Constants.RUN);
				AddTranslation(languageSection, Constants.SET);
				AddTranslation(languageSection, Constants.SIZE);
        		AddTranslation(languageSection, Constants.WRITE);
				AddTranslation(languageSection, Constants.WRITELINE);
				AddTranslation(languageSection, Constants.WRITELINES);
       			AddTranslation(languageSection, Constants.WRITENL);

				// Специални сделки за други, elif, тъй като те не са отделни
// функции, но са част от блок-декларацията if.
// Същото и, или не.
				AddSubstatementTranslation(languageSection, Constants.ELSE,    Constants.ELSE_LIST);
				AddSubstatementTranslation(languageSection, Constants.ELSE_IF, Constants.ELSE_IF_LIST);
				AddSubstatementTranslation(languageSection, Constants.CATCH,   Constants.CATCH_LIST);
			}
		}

		public int ReadConfig(string configName, int defaultValue = 0)
		{
			string config = ConfigurationManager.AppSettings[configName];
			int value = defaultValue;
			if (string.IsNullOrWhiteSpace(config) || !Int32.TryParse(config, out value))
			{
				return defaultValue;
			}

			return value;
		}

		public void AddTranslation(NameValueCollection languageDictionary, string originalName)
		{
			string translation = languageDictionary[originalName];
			if (string.IsNullOrWhiteSpace(translation))
			{ // Преводът не е предвиден за тази функция.
				return;
			}

			if (translation.IndexOfAny((" \t\r\n").ToCharArray()) >= 0)
			{
				throw new ArgumentException("Translation of [" + translation + "] contains white spaces");
			}

			ParserFunction originalFunction = ParserFunction.GetFunction(originalName);
			ParserFunction.AddGlobal(translation, originalFunction);

			// Ако списъкът с функции, след които може да има интервал (освен скоби)
			// съдържа оригиналната функция, също добавете превод към списъка.
			if (Constants.FUNCT_WITH_SPACE.Contains(originalName)) {
				Constants.FUNCT_WITH_SPACE.Add(translation);
			}
		}

		public void AddSubstatementTranslation(NameValueCollection languageDictionary,
			string originalName, List<string> keywordsArray)
		{
			string translation = languageDictionary[originalName];
			if (string.IsNullOrWhiteSpace(translation))
			{ // Преводът не е предоставен за този под-отчет.
				return;
			}

			if (translation.IndexOfAny((" \t\r\n").ToCharArray()) >= 0)
			{
				throw new ArgumentException("Translation of [" + translation + "] contains white spaces");
			}

			keywordsArray.Add(translation);
		}

		public Variable Process(string script)
		{
			string data = Utils.ConvertToScript(script);
      if (string.IsNullOrWhiteSpace (data)) {
				return null;
			}

			int currentChar = 0;
			Variable result = null;

      while (currentChar < data.Length)
			{
        result = Parser.LoadAndCalculate(data, ref currentChar, Constants.END_PARSE_ARRAY);
        Utils.GoToNextStatement(data, ref currentChar);
			}

			return result;
		}

		internal Variable ProcessWhile(string data, ref int from)
		{
			int startWhileCondition = from;

			// Проверка срещу безкраен цикъл.
			int cycles = 0;
			bool stillValid = true;

			while (stillValid)
			{
				from = startWhileCondition;

				//int startSkipOnBreakChar = from;
				Variable condResult = Parser.LoadAndCalculate(data, ref from, Constants.END_ARG_ARRAY);
				stillValid = Convert.ToBoolean(condResult.Value);

				if (!stillValid)
				{
					break;
				}

				// Проверете за безкраен цикъл, ако сравняваме едни и същи стойности:
				if (MAX_LOOPS > 0 && ++cycles >= MAX_LOOPS)
				{
					throw new ArgumentException("Looks like an infinite loop after " +
						cycles + " cycles.");
				}

				Variable result = ProcessBlock(data, ref from);
        if (result.Type == Variable.VarType.BREAK)
				{
          from = startWhileCondition;
					break;
				}
			}

			// Състоянието на времето вече не е вярно: трябва да прескочите цялото време
			// блок, преди да продължите с следващите изявления.
			SkipBlock(data, ref from);
			return new Variable();
		}

		internal Variable ProcessIf(string data, ref int from)
		{
			int startIfCondition = from;

			Variable result = Parser.LoadAndCalculate(data, ref from, Constants.END_ARG_ARRAY);
			bool isTrue = Convert.ToBoolean(result.Value);

			if (isTrue)
			{
				result = ProcessBlock(data, ref from);

        if (result.Type == Variable.VarType.BREAK ||
            result.Type == Variable.VarType.CONTINUE)
				{
					// Имате тук от средата на блока. Пропуснете го.
					from = startIfCondition;
					SkipBlock(data, ref from);
				}
				SkipRestBlocks(data, ref from);

        return result;
			}

			// Ние сме в други. Пропуснете всичко в израза "Ако".
			SkipBlock(data, ref from);

			int endOfToken = from;
			string nextToken = Utils.GetNextToken(data, ref endOfToken);

			if (Constants.ELSE_IF_LIST.Contains(nextToken))
			{
				from = endOfToken + 1;
				result = ProcessIf(data, ref from);
			}
			else if (Constants.ELSE_LIST.Contains(nextToken))
			{
				from = endOfToken + 1;
				result = ProcessBlock(data, ref from);
			}

      return Variable.EmptyInstance;
		}

		internal Variable ProcessTry(string data, ref int from)
		{
			int startTryCondition = from - 1;
			int currentStackLevel = ParserFunction.GetCurrentStackLevel();
			Exception exception   = null;

			Variable result = null;

			try {
				result = ProcessBlock(data, ref from);
			}
			catch(ArgumentException exc) {
				exception = exc;
			}

if (exception != null ||
    result.Type == Variable.VarType.BREAK ||
    result.Type == Variable.VarType.CONTINUE)
{
	// Имате тук от средата на пробния блок или защото
// изхвърлено изключение или поради прекъсване / продължаване. Пропуснете го.
	from = startTryCondition;
	SkipBlock(data, ref from);
}

			string catchToken = Utils.GetNextToken(data, ref from);
			from++; // пропуснете отварянето на скобите
			// Следващият знак след пробния блок трябва да бъде улов.
			if (!Constants.CATCH_LIST.Contains(catchToken))
			{
				throw new ArgumentException("Expecting a 'catch()' but got [" +
					catchToken + "]");
			}

			string exceptionName = Utils.GetNextToken(data, ref from);
			from++; // пропуснете скобата за затваряне

			if (exception != null) {
				string excStack = CreateExceptionStack(currentStackLevel);
				ParserFunction.InvalidateStacksAfterLevel(currentStackLevel);

				GetVarFunction excFunc = new GetVarFunction(new Variable(exception.Message + excStack));
				ParserFunction.AddGlobalOrLocalVariable(exceptionName, excFunc);

				result = ProcessBlock(data, ref from);
				ParserFunction.PopLocalVariable(exceptionName);
			} else {
				SkipBlock (data, ref from);
			}
				
			SkipRestBlocks(data, ref from);
			return result;
		}

		private static string CreateExceptionStack(int lowestStackLevel) {
			string result = "";
			Stack<ParserFunction.StackLevel> stack = ParserFunction.ExecutionStack;
			int level = stack.Count;
			foreach (ParserFunction.StackLevel stackLevel in stack) {
				if (level-- < lowestStackLevel) {
					break;
				}
				if (string.IsNullOrWhiteSpace(stackLevel.Name)) {
					continue;
				}
				result += Environment.NewLine + "  " + stackLevel.Name + "()";
			}

			if (!string.IsNullOrWhiteSpace (result)) {
				result = " at" + result;
			}

			return result;
		}

		private Variable ProcessBlock(string data, ref int from)
		{
			int blockStart = from;
			Variable result = null;

			while(from < data.Length)
			{
				int endGroupRead = Utils.GoToNextStatement(data, ref from);
				if (endGroupRead > 0)
				{
					return result != null ? result : new Variable();
				}

				if (from >= data.Length)
				{
					throw new ArgumentException("Couldn't process block [" +
						data.Substring(blockStart) + "]");
				}

				result = Parser.LoadAndCalculate(data, ref from, Constants.END_PARSE_ARRAY);


        if (result.Type == Variable.VarType.BREAK ||
            result.Type == Variable.VarType.CONTINUE) {
				 return result;
				}
			}
			return result;
		}

		private void SkipBlock(string data, ref int from)
		{
			int blockStart = from;
			int startCount = 0;
			int endCount = 0;
			while (startCount == 0 || startCount > endCount)
			{
				if (from >= data.Length)
				{
					throw new ArgumentException("Couldn't skip block [" + data.Substring(blockStart) + "]");
				}
				char currentChar = data[from++];
				switch (currentChar)
				{
				case Constants.START_GROUP: startCount++; break;
				case Constants.END_GROUP:   endCount++; break;
				}
			}

			if (startCount != endCount)
			{
				throw new ArgumentException("Mismatched parentheses");
			}
		}

		private void SkipRestBlocks(string data, ref int from)
		{
			while (from < data.Length)
			{
				int endOfToken = from;
				string nextToken = Utils.GetNextToken(data, ref endOfToken);
				if (!Constants.ELSE_IF_LIST.Contains(nextToken) &&
					!Constants.ELSE_LIST.Contains(nextToken))
				{
					return;
				}
				from = endOfToken;
				SkipBlock(data, ref from);
			}
		}
	}
}
